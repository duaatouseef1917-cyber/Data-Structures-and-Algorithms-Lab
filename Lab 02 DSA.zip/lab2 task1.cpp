#include <iostream>
using namespace std;
int main() 
{
    int arr[5]={10,15,20,25,30};
    int*ptr=arr;  
    cout<<"Array elements are:"<<endl;
    for(int i =0;i<5;i++) 
	{
        cout<<*(ptr+i)<<endl;
    }
    return 0;
}